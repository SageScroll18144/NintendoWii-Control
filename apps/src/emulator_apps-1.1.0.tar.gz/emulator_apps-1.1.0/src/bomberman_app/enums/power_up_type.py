from enum import Enum


class PowerUpType(Enum):

    BOMB = 0
    FIRE = 1

