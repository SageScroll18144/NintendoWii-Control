# Agar.io clone

Python clone of agar.io game, made with pygame.

Should work with both python 2.7 and python 3.2

### Dependencies
- Pygame
- Python

### Screenshot
![Alt text](https://cloud.githubusercontent.com/assets/13442473/10423082/287f4852-711f-11e5-8882-9cef137180eb.png "Screenshot")
