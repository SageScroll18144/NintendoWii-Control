# -*- coding: utf-8 -*-

screen_width = 480
screen_height = 640

platform_width = 100
fps = 45

doodle_start_position = [240,350]

horizont = 300
mouse_enabled = False
transparent_walls = True

platform_count = 10
gravitation = 0.4
jump_speed = 15
spring_speed = 20

platform_y_padding = 7
